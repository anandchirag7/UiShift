```

---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
SELECT * FROM "ecc.NonCumulativeSales";

-- expected results
SELECT "Date", "Material", "Inflow", "Outflow", "Balance" AS "Daily Balance"
FROM "5.sol::CvStockBalanceQuery" ORDER BY "Date";

-- cross join
SELECT A."Date", A."Material", B."Inflow", B."Outflow"
FROM "ecc.NonCumulativeSales" A, "ecc.NonCumulativeSales" B
WHERE A."Date">=B."Date" and A."Material"=B."Material"
ORDER BY 1;

-- calculate the balance
SELECT "Date", "Material", SUM("InFlow") AS "InFlow", SUM("OutFlow") AS "OutFlow", SUM("InFlow"-"OutFlow") AS "Balance" 
FROM 
	(
		SELECT A."Date" AS "Date", A."Material" AS "Material", B."Inflow" AS "InFlow", B."Outflow" AS "OutFlow"
		FROM "ecc.NonCumulativeSales" A, "ecc.NonCumulativeSales" B
		WHERE A."Date">=B."Date" and A."Material"=B."Material"
		ORDER BY 1
	)
GROUP BY "Date", "Material";


-- Join back to the Original data source to get the correct daily Inflow and Outflows
SELECT 
	C."Date" AS "Date", C."Material" AS "Material", SUM(D."Inflow") AS "InFlow", SUM(D."Outflow") AS "OutFlow", SUM(C."Balance") AS "Balance" 
FROM 
	(
		SELECT "Date", "Material", SUM("InFlow") AS "InFlow", SUM("OutFlow") AS "OutFlow", SUM("InFlow"-"OutFlow") AS "Balance" 
		FROM 
			(
				SELECT A."Date" AS "Date", A."Material" AS "Material", B."Inflow" AS "InFlow", B."Outflow" AS "OutFlow"
				FROM "ecc.NonCumulativeSales" A, "ecc.NonCumulativeSales" B
				WHERE A."Date">=B."Date" and A."Material"=B."Material"
				ORDER BY 1
			) 
		GROUP BY "Date", "Material"
	) C
JOIN "ecc.NonCumulativeSales" D ON 
	C."Date" = D."Date" AND C."Material" = D."Material"
GROUP BY C."Date", C."Material";


---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "Date", "Material", "Inflow", "Outflow", "Balance" AS "Daily Balance"
FROM "5.exe::CvStockBalanceQuery" ORDER BY "Date";


```

