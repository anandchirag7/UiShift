```
---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
SELECT * FROM "ecc.Stock";

SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount" 
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

SELECT "Symbol", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

-- wrong when both measures are selected
SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

SELECT "Symbol", COUNT(DISTINCT "CC_Symbol") AS "SymbolCount", COUNT(DISTINCT "CC_Day") AS "SymbolDayCount" 
FROM 
	(
	SELECT "Symbol", NULL AS "Date", NULL AS "CC_Day", "CC_Symbol" 
	FROM  "1.sol::CvStockGainsAndLossesQuery"
	UNION ALL
	SELECT "Symbol", "Date", "CC_Day", NULL AS "CC_Symbol" 
	FROM "1.sol::CvStockGainsAndLossesQuery"
	)
GROUP BY "Symbol";

SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesUnionSolutionQuery"
GROUP BY "Symbol";

SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesStackedSolutionQuery"
GROUP BY "Symbol";

---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount" 
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

--SQL #2
SELECT "Symbol", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

--SQL #3
SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.sol::CvStockGainsAndLossesQuery"
GROUP BY "Symbol";

--SQL #4
SELECT "Symbol", COUNT(DISTINCT "CC_Symbol") AS "SymbolCount", COUNT(DISTINCT "CC_Day") AS "SymbolDayCount" 
FROM (
	SELECT "Symbol", NULL AS "Date", NULL AS "CC_Day", "CC_Symbol" 
	FROM  "1.sol::CvStockGainsAndLossesQuery"
	UNION ALL
	SELECT "Symbol", "Date", "CC_Day", NULL AS "CC_Symbol" 
	FROM "1.sol::CvStockGainsAndLossesQuery"
)
GROUP BY "Symbol";

--SQL #5
SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.exe::CvStockGainsAndLossesUnionSolutionQuery"
GROUP BY "Symbol";

--SQL #6
SELECT "Symbol", SUM("SymbolCount") AS "SymbolCount", SUM("SymbolDayCount") AS "SymbolDayCount"
FROM "1.exe::CvStockGainsAndLossesStackedSolutionQuery"
GROUP BY "Symbol";
```
