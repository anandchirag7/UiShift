```
---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
SELECT "OrgHierarchyNode", sum("Revenue") AS "Revenue", sum("Cost") AS "Cost", sum("Margin") AS "Margin" 
FROM "7.sol::CvSalesHierarchyQuery" 
GROUP BY "OrgHierarchyNode" ORDER BY "OrgHierarchyNode";

SELECT "EmployeeID", sum("Revenue") AS "Revenue", sum("Cost") AS "Cost", sum("Margin") AS "Margin" 
FROM "7.sol::CvSalesHierarchyQuery" 
WHERE "OrgHierarchyNode" = 'Alice' GROUP BY "EmployeeID";

---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "OrgHierarchynode", sum("Revenue") AS "Revenue", sum("Cost") AS "Cost", sum("Margin") AS "Margin" 
FROM "7.exe::CvSalesHierarchyQuery" 
GROUP BY "OrgHierarchynode" ORDER BY "OrgHierarchynode";

--SQL #2
SELECT "EmployeeID", sum("Revenue") AS "Revenue", sum("Cost") AS "Cost", sum("Margin") AS "Margin" 
FROM "7.exe::CvSalesHierarchyQuery" 
WHERE "OrgHierarchynode" = 'Alice' GROUP BY "EmployeeID";

```