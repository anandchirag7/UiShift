```
---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
SELECT * FROM "ecc.CumulativeSales";
SELECT * FROM "6.sol::TfMatrixGeneratorUtil" ( ) ;
SELECT * FROM "ecc.SlowProduct";
 
SELECT "Year",  "Flag" as "Month", SUM("Sale") AS "Rolling" 
FROM "6.sol::CvSales" 
WHERE "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Flag";

SELECT "Year",  "Flag" as "Month", "Name", SUM("Sale") AS "Rolling" 
FROM "6.sol::CvSales" 
WHERE "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Flag", "Name"
ORDER BY 1,2;

SELECT "Year", "Month", "ProductID", "Name", SUM("Sale") AS "Sale" , SUM("Rolling") AS "Rolling"
FROM "6.sol::CvCumulativeSalesQuery" 
WHERE "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Month", "ProductID", "Name"
ORDER BY "Year", "Month", "ProductID";

SELECT "Year", "Month", "ProductID", "Name", "Brand", SUM("Sale") AS "Sale" 
FROM "6.sol::CvCumulativeSalesQuery" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Month", "ProductID", "Name", "Brand" 
ORDER BY "Year", "Month", "ProductID";

---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "Month", "Flag", "Product" FROM "ecc.MonthsAndProducts" 
ORDER BY "Flag", "Month", "Product";
 
--SQL #2
SELECT "Year",  "Flag" as "Month", sum("Sale") AS "Rolling" 
FROM "6.exe::CvSales" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY  "Year", "Flag" ORDER BY 1,2;

--SQL #3
SELECT "Year",  "Flag" as "Month", "ProductID", "Name", sum("Sale") AS "Rolling" 
FROM "6.exe::CvSales" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY  "Year", "Flag", "ProductID", "Name"
ORDER BY "Year", "Flag", "ProductID";

--SQL #4
SELECT "Year", "Month", sum("Sale") AS "Sale", sum("Rolling") AS "Rolling"
FROM "6.exe::CvCumulativeSalesQuery" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Month" ORDER BY 1,2;

--SQL #5
SELECT "Year", "Month", "Name", sum("Sale") AS "Sale", sum("Rolling") AS "Rolling"
FROM "6.exe::CvCumulativeSalesQuery" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231'
GROUP BY "Year", "Month", "Name" ORDER BY 1,2,3;

--SQL #6
SELECT  "Year","Month", "Name", "Brand", sum("Sale") AS "Sale", sum("Rolling") AS "Rolling"
FROM "6.exe::CvCumulativeSalesQuery" 
WHERE  "OrderDate" BETWEEN '20130101' AND '20131231' 
GROUP BY "Year", "Month", "Name", "Brand" ORDER BY 1,2,3;

--SQL #7
SELECT * FROM "ecc.SlowProduct";


```