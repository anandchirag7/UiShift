``` 
---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
-- correct when team is selected
SELECT "TeamName", "PlayerName", SUM("PlayerGoals") AS "PlayerGoals"
FROM "3.sol::CvRankTeamPlayerSolutionQuery" (PLACEHOLDER."$$TOP_N_PLAYERS$$"=>2)
GROUP BY "TeamName", "PlayerName";

-- wrong when only players are selected, query should return 2 rows but returns more records
SELECT "PlayerName", SUM("PlayerGoals") AS "PlayerGoals"
FROM "3.sol::CvRankTeamPlayerSolutionQuery" (PLACEHOLDER."$$TOP_N_PLAYERS$$"=>3)
GROUP BY "PlayerName";

SELECT "PlayerName", SUM("PlayerGoals") AS "PlayerGoals"
FROM "3.sol::CvRankTeamPlayerDynamicSolutionQuery" (PLACEHOLDER."$$TOP_N_PLAYERS$$"=>3)
GROUP BY "PlayerName";

---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "TeamName", "PlayerName", SUM("PlayerGoals") AS "PlayerGoals"
FROM "3.exe::CvRankTeamPlayerDynamicSolutionQuery" (PLACEHOLDER."$$TOP_N_PLAYERS$$"=>2)
GROUP BY "TeamName", "PlayerName";

--SQL #2
SELECT "PlayerName", SUM("PlayerGoals") AS "PlayerGoals"
FROM "3.exe::CvRankTeamPlayerDynamicSolutionQuery" (PLACEHOLDER."$$TOP_N_PLAYERS$$"=>3)
GROUP BY "PlayerName";


```