```
---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
-- blocked unfolding, filters blocked, tables not pruned
SELECT "Vkorg", SUM("ActualNetRevenue") AS "ActualNetRevenue",  SUM("PlannedNetRevenue") AS "PlannedNetRevenue"
FROM "2.sol::CvProfitabilityAnalysisScriptedQuery" 
WHERE "Vkorg" = '1000' GROUP BY "Vkorg";

-- solution, model unfolds, filters are pushed down, tables are pruned
SELECT "Vkorg", SUM("ActualNetRevenue") AS "ActualNetRevenue",  SUM("PlannedNetRevenue") AS "PlannedNetRevenue"
FROM "2.sol::CvProfitabilityAnalysisSolutionQuery" 
WHERE "Vkorg" = '1000' GROUP BY "Vkorg";

-- calculated column blocking unfolding
SELECT "CC_Germany", SUM("ActualNetRevenue") AS "ActualNetRevenue",  SUM("PlannedNetRevenue") AS "PlannedNetRevenue"
FROM "2.sol::CvProfitabilityAnalysisSolutionQuery" 
GROUP BY "CC_Germany";

---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "Vkorg", SUM("ActualNetRevenue") AS "ActualNetRevenue",  SUM("PlannedNetRevenue") AS "PlannedNetRevenue"
FROM "2.exe::CvProfitabilityAnalysisScriptedQuery" 
WHERE "Vkorg" = '1000'
GROUP BY  "Vkorg";

--SQL #2
SELECT "Vkorg", SUM("ActualNetRevenue") AS "ActualNetRevenue",  SUM("PlannedNetRevenue") AS "PlannedNetRevenue"
FROM "2.exe::CvProfitabilityAnalysisSolutionQuery" 
WHERE "Vkorg" = '1000'
GROUP BY  "Vkorg";

--SQL #3
SELECT "CC_Germany","Gjahr","Vkorg","Matnr"
FROM "2.exe::CvProfitabilityAnalysisSolutionQuery" 
WHERE "Vkorg" = '1000';

```
