```

---------------------------------------------------------------------------------------------------
--SOLUTION SQL
---------------------------------------------------------------------------------------------------
-- Automatically select 2016 as cold prev-year if no param is supplied
SELECT "Country", SUM("PreviousAmount") AS "2016", SUM("CurrentAmount") AS "2017"
FROM "4.sol::CvSalesByYearComparisonQuery" 
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

-- Force 2015 as cold year
SELECT "Country", SUM("PreviousAmount") AS "2015", SUM("CurrentAmount") AS "2017"
FROM "4.sol::CvSalesByYearComparisonQuery" ('PLACEHOLDER' = ('$$IP_COLD_YEAR$$', '2015')) 
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

-- Cold call
SELECT "Country", SUM("PreviousAmount") AS "2015"
FROM "4.sol::CvSalesByYearComparisonQuery"  ('PLACEHOLDER' = ('$$IP_COLD_YEAR$$', '2015')) 
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil') AND "SOURCE" = 'IQ' 
GROUP BY "Country" ORDER BY "Country";

-- Hot call
SELECT "Country", SUM("CurrentAmount") AS "2017"
FROM "4.sol::CvSalesByYearComparisonQuery"
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil') AND "SOURCE" = 'HANA' 
GROUP BY "Country" ORDER BY "Country";

-- Empty union behaviour! For Value Help Lookup queries
SELECT DISTINCT "SOURCE" FROM "4.sol::CvSalesByYearComparisonQuery"

-- Hot call without using Constant Column
SELECT "Country", SUM("TotalAmount") AS "2017"
FROM "4.sol::CvSalesByYearUsingPruningNodeQuery" 
WHERE "Year" = '2017' AND "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";


---------------------------------------------------------------------------------------------------
--STUDENT SQL
---------------------------------------------------------------------------------------------------
--SQL #1
SELECT "Country", SUM("PreviousAmount") AS "2016", SUM("CurrentAmount") AS "2017"
FROM "4.exe::CvSalesByYearComparisonQuery" 
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

--SQL #2
--Force 2016 as cold year
SELECT "Country", SUM("PreviousAmount") AS "2016", SUM("CurrentAmount") AS "2017"
FROM "4.exe::CvSalesByYearComparisonQuery" ('PLACEHOLDER' = ('$$IP_COLD_YEAR$$', '2016')) 
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

--SQL #3
SELECT "Country", SUM("CurrentAmount") AS "2017"
FROM "4.exe::CvSalesByYearComparisonQuery"
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil') 
GROUP BY "Country" ORDER BY "Country";

--SQL #4
SELECT "Country", SUM("CurrentAmount") AS "2017"
FROM "4.exe::CvSalesByYearComparisonQuery"
WHERE "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil') AND "SOURCE" = 'HANA' 
GROUP BY "Country" ORDER BY "Country"
WITH HINT (NO_RESULT_CACHE);

--SQL #5
--Empty union behaviour! For Value Help Lookup queries
SELECT DISTINCT "SOURCE" FROM "4.exe::CvSalesByYearComparisonQuery"

--SQL #6
SELECT "Country", SUM("TotalAmount") AS "2017"
FROM "4.exe::CvSalesByYearUsingPruningNodeQuery" 
WHERE "Year" > '2016' AND "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

--SQL #7
SELECT "Country", SUM("TotalAmount") AS "2015-2016"
FROM "4.exe::CvSalesByYearUsingPruningNodeQuery" 
WHERE "Year" <= '2016' AND "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')
GROUP BY "Country" ORDER BY "Country";

--SQL #8
-- Pruning blocked because of NO aggregation
SELECT "Country", "City", "Year"
FROM "4.exe::CvSalesByYearUsingPruningNodeQuery" 
WHERE "Year" = '2017' AND "Country" IN ('USA', 'Germany', 'France', 'Sweden', 'Brazil')


```


