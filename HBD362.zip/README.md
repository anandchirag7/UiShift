# HBD362
TechEd 2017 Advanced Modeling

General Message:
===================================================
- XSA/WebIDE/Graphical calculation models
- Regularly check model unfolding and/or filter push down
- Optimize models by using 
    - star-joins
	- left outer joins
	- join optimization
	- join cardinality
	- dynamic join
	- lookup value models
	- union pruning
- When requiring scripts use table functions (understand the nuances between SQL Script vs Models)

Exercises:  
===================================================
- Multi level aggregation using counters (different granularity levels)
- Models vs Scripts (pruning, blockers, variables, filters, pros/cons, etc.)
- Rank node unexpected results (dynamic ranking)
- Union node pruning (explicit vs implicit pruning)
- SQL puzzle, non-cumulative key figures (cross join, data exploding/imploding)
- Slowly changing dimensions (star/temporal join, transparent filter, keep flag, dynamic join)
- SQL hierarchy + SQL analytical privileges