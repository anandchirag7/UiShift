# TechEd2017.HBD260
TechEd 2017 HBD260 Template: Introduction to Node.js

With the introduction of SAP HANA extended application services, advanced model to SAP HANA and SAP Cloud Platform, we see the increased use of JavaScript on the server side, and more specifically Node.js. We are seeing the evolution from the XSJS programming model into native Node.js with its nonblocking I/O and asynchronous flow. We will see general Node.js best practices, use of NPM modules, Web sockets, and OData V4.
